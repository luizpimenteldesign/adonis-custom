<?php
class Database {
    private $host = 'localhost';
    private $db_name
