    <footer class="footer mt-5">
        <div class="footer-container">
            <p class="footer-text">© 2026 Adonis Custom Luthieria. Todos os direitos reservados.</p>
            <div class="footer-links">
                <a href="/adonis-custom/frontend/index.html" class="footer-link">Solicitar Orçamento</a>
                <a href="#" class="footer-link">Política de Privacidade</a>
                <a href="#" class="footer-link">Termos de Uso</a>
            </div>
        </div>
    </footer>
</body>
</html>
